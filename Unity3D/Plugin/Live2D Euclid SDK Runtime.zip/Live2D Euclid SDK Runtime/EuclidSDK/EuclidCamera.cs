﻿/*
*Copyright(c) Live2D Inc. All rights reserved.
*このソースコードの使用には、"http://www.live2d.com/eula/live2d-open-software-license-agreement_jp.html"ファイルにあるLive2D Open Software ライセンスが適用されます。
*Use of this source code is governed by a Live2D Open Software license that can be found in the "http://www.live2d.com/eula/live2d-open-software-license-agreement_en.html" file.
*/

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Assertions;
using live2d.Euclid;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class EuclidCamera : MonoBehaviour
{
#if UNITY_EDITOR
    EuclidCamera()
    {
        UnityEditor.AssemblyReloadEvents.afterAssemblyReload += OnAssemblyReloaded;
    }
    ~EuclidCamera()
    {
        UnityEditor.AssemblyReloadEvents.afterAssemblyReload -= OnAssemblyReloaded;
    }

    // Assemblyのリロードが行われる際にAwake/Start/OnDestroyは呼ばれない[1]ので、それらに依存した処理は追加で処理する必要がある
    //
    // 残念ながらAssemblyReloadEventsがcallbackを発行するタイミングはOnDisableの前、OnEnableの後なので直接OnDestroyとAwakeを呼ぶのでは不適
    //      1. beforeAssemblyReload
    //      2. OnDisable
    //      3. finalizer
    //      4. constructor
    //      5. OnEnable
    //      6. afterAssemblyReload
    //
    // Awakeしていない状態で呼ばれたOnEnableは無害なので、afterAssemblyReloadで1からやり直すことにする
    // 副作用としてEuclidModelAsset.OnEnableとのデータレースもこれで解決される
    //
    // [1] https://issuetracker.unity3d.com/issues/awake-and-start-not-called-before-update-when-assembly-is-reloaded-for-executeineditmode-scripts
    private void OnAssemblyReloaded()
    {
        Awake();
        if (isActiveAndEnabled)
        {
            OnEnable();
        }
    }
#endif

    // ExecuteInEditModeAttributeがあると、エディットモードからプレイモードへの遷移途中でもAwake/OnEnable等のメッセージが発行される
    // この間は描画の必要が無いのでスキップさせる
    private static bool playmodeChanging
    {
#if UNITY_EDITOR
        get { return UnityEditor.EditorApplication.isPlaying
                  != UnityEditor.EditorApplication.isPlayingOrWillChangePlaymode; }
#else
        get { return false; }
#endif
    }

    [SerializeField]
    private List<EuclidModel> TargetEuclidModel = new List<EuclidModel>();

#if UNITY_EDITOR
    // Unityインスペクタ上でモデルの増減があるとき、増は対応できるが
    // 減が対応できないので実際にインスタンスを作ったリストを作る
    private List<EuclidModel> _instanced_models = new List<EuclidModel>();
#endif

    private List<EuclidModel> models
    {
#if UNITY_EDITOR
        get { return _instanced_models; }
#else
        get { return TargetEuclidModel; }
#endif
    }

    internal EuclidCameraBackend backend = new EuclidCameraBackend(false);

    public void AddEuclidModel(EuclidModel model)
    {
        if (model == null || models.Contains(model)) { return; }

        models.Add(model);
#if UNITY_EDITOR
        if (!TargetEuclidModel.Contains(model))
        {
            TargetEuclidModel.Add(model);
        }
#endif

        var modelBackend = acquireBackend(model);
        backend.registerEuclidModel(modelBackend);

        backend.InitializeModel(transform, modelBackend);
    }

    public void RemoveEuclidModel(EuclidModel model)
    {
        if (model == null) { return; }

        int index = models.IndexOf(model);
        if (index == -1) { return; }

        backend.Close(index);

        var modelBackend = backend.unregisterEuclidModel(index);
        bool result = releaseBackend(index, modelBackend);
        Debug.Assert(result, this);

        models.RemoveAt(index);
#if UNITY_EDITOR
        TargetEuclidModel.Remove(model);
#endif
    }

    private EuclidModelBackend acquireBackend(EuclidModel model)
    {
        var modelBackend = model.AddBackend();
        model.Destroied += OnModelDestroied;
        return modelBackend;
    }

    private bool releaseBackend(int index, EuclidModelBackend modelBackend)
    {
        models[index].Destroied -= OnModelDestroied;
        return models[index].RemoveBackend(modelBackend);
    }

    private void OnModelDestroied(EuclidModel model)
    {
        // この時点ですでにEuclidModelBackendは完全に破棄されているので消していくだけでよい

        Assert.IsNotNull(model);

        int index = models.IndexOf(model);
        Assert.AreNotEqual(-1, index);

        backend.unregisterEuclidModel(index);
        models.RemoveAt(index);
#if UNITY_EDITOR
        TargetEuclidModel.Remove(model);
#endif
    }

    #region Unity Functions
    private void Awake()
    {
        if (playmodeChanging) { return; }

        Shader.SetGlobalInt("euclid_RenderingEye", 0);
        Assert.AreEqual(0, backend.ModelCount);

#if UNITY_EDITOR
        _instanced_models.Clear();
        _instanced_models.AddRange(TargetEuclidModel);
#endif
        foreach (var m in TargetEuclidModel)
        {
            var modelBackend = acquireBackend(m);
            backend.registerEuclidModel(modelBackend);
        }
    }

    private void OnEnable()
    {
        if (playmodeChanging) { return; }

        backend.InitializeModel(transform);
    }

    private void Update()
    {
        // カメラや3Dモデルの情報からEuclidモデルの向きに関するパラメータを更新する
        backend.UpdateEuclidModelParameter(transform.position);
    }

    private void LateUpdate()
    {
        // カメラや3Dモデルの情報からEuclidモデルの向きに関するパラメータを更新する
        backend.LateUpdateEuclidModelParameter(transform.position);
    }

    private void OnDisable()
    {
        backend.Close();
    }

    private void OnDestroy()
    {
        int index = backend.ModelCount;
        while (0 < index--)
        {
            var modelBackend = backend.unregisterEuclidModel(index);
            // SceneのDestory時はEuclidModelのDestoryのほうが早い場合もあるので戻り値の検査は行わない
            releaseBackend(index, modelBackend);
        }
    }
    #endregion
}
