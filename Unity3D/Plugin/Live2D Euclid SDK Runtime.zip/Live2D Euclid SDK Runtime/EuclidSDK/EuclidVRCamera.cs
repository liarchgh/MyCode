﻿/*
*Copyright(c) Live2D Inc. All rights reserved.
*このソースコードの使用には、"http://www.live2d.com/eula/live2d-open-software-license-agreement_jp.html"ファイルにあるLive2D Open Software ライセンスが適用されます。
*Use of this source code is governed by a Live2D Open Software license that can be found in the "http://www.live2d.com/eula/live2d-open-software-license-agreement_en.html" file.
*/

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.XR;
using live2d.Euclid;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class EuclidVRCamera : MonoBehaviour
{
#if UNITY_EDITOR
    EuclidVRCamera()
    {
        UnityEditor.AssemblyReloadEvents.afterAssemblyReload += OnAssemblyReloaded;
    }
    ~EuclidVRCamera()
    {
        UnityEditor.AssemblyReloadEvents.afterAssemblyReload -= OnAssemblyReloaded;
    }

    // Assemblyのリロードが行われる際にAwake/Start/OnDestroyは呼ばれない[1]ので、それらに依存した処理は追加で処理する必要がある
    //
    // 残念ながらAssemblyReloadEventsがcallbackを発行するタイミングはOnDisableの前、OnEnableの後なので直接OnDestroyとAwakeを呼ぶのでは不適
    //      1. beforeAssemblyReload
    //      2. OnDisable
    //      3. finalizer
    //      4. constructor
    //      5. OnEnable
    //      6. afterAssemblyReload
    //
    // Awakeしていない状態で呼ばれたOnEnableは無害なので、afterAssemblyReloadで1からやり直すことにする
    // 副作用としてEuclidModelAsset.OnEnableとのデータレースもこれで解決される
    //
    // [1] https://issuetracker.unity3d.com/issues/awake-and-start-not-called-before-update-when-assembly-is-reloaded-for-executeineditmode-scripts
    private void OnAssemblyReloaded()
    {
        Awake();
        if (isActiveAndEnabled)
        {
            OnEnable();
            Start();
        }
    }
#endif

    // ExecuteInEditModeAttributeがあると、エディットモードからプレイモードへの遷移途中でもAwake/OnEnable等のメッセージが発行される
    // この間は描画の必要が無いのでスキップさせる
    private static bool playmodeChanging
    {
#if UNITY_EDITOR
        get { return UnityEditor.EditorApplication.isPlaying
                  != UnityEditor.EditorApplication.isPlayingOrWillChangePlaymode; }
#else
        get { return false; }
#endif
    }

    [SerializeField]
    private List<EuclidModel> TargetEuclidModel = new List<EuclidModel>();
    [SerializeField]
    public float BothEyeOffset = 0.0f; // Adjust parallax

#if UNITY_EDITOR
    // Unityインスペクタ上でモデルの増減があるとき、増は対応できるが
    // 減が対応できないので実際にインスタンスを作ったリストを作る
    private List<EuclidModel> _instanced_models = new List<EuclidModel>();
#endif

    private List<EuclidModel> models
    {
#if UNITY_EDITOR
        get { return _instanced_models; }
#else
        get { return TargetEuclidModel; }
#endif
    }

    private EuclidCameraBackend backendLeft  = new EuclidCameraBackend(false);
    private EuclidCameraBackend backendRight = new EuclidCameraBackend(true);

    private float leftCameraOffset;
    private float rightCameraOffset;
    private float eyeOffset;

    private int _renderingEyeId;
    private int _currentEye = 0;

    private struct ModelBackendPair
    {
        public EuclidModelBackend left;
        public EuclidModelBackend right;

        public ModelBackendPair(EuclidModelBackend left, EuclidModelBackend right)
        {
            this.left  = left;
            this.right = right;
        }
    }

    public void AddEuclidModel(EuclidModel model)
    {
        if (model == null || models.Contains(model)) { return; }

        models.Add(model);
#if UNITY_EDITOR
        if (!TargetEuclidModel.Contains(model))
        {
            TargetEuclidModel.Add(model);
        }
#endif

        var modelBackend = acquireBackend(model);
        backendLeft.registerEuclidModel(modelBackend.left);
        backendRight.registerEuclidModel(modelBackend.right);

        backendLeft.InitializeModel(transform, modelBackend.left);
        backendRight.InitializeModel(transform, modelBackend.right);
    }

    public void RemoveEuclidModel(EuclidModel model)
    {
        if (model == null) { return; }

        int index = models.IndexOf(model);
        if (index == -1) { return; }

        backendLeft.Close(index);
        backendRight.Close(index);

        var modelBackendL = backendLeft.unregisterEuclidModel(index);
        var modelBackendR = backendRight.unregisterEuclidModel(index);
        bool result = releaseBackend(index, new ModelBackendPair(modelBackendL, modelBackendR));
        Debug.Assert(result, this);

        models.RemoveAt(index);
#if UNITY_EDITOR
        TargetEuclidModel.Remove(model);
#endif
    }

    private ModelBackendPair acquireBackend(EuclidModel model)
    {
        var pair = new ModelBackendPair
        {
            left  = model.AddBackend(),
            right = model.AddBackend(),
        };
        model.Destroied += OnModelDestroied;
        return pair;
    }

    private bool releaseBackend(int index, ModelBackendPair modelBackend)
    {
        models[index].Destroied -= OnModelDestroied;
        bool result = models[index].RemoveBackend(modelBackend.left);
        // short-circuitでremoveが飛ばされないように注意
        return models[index].RemoveBackend(modelBackend.right) && result;
    }


    public void ResetParallaxOffset()
    {
        var center = InputTracking.GetLocalPosition(XRNode.CenterEye);

        leftCameraOffset  = (center - InputTracking.GetLocalPosition(XRNode.LeftEye)).magnitude;
        rightCameraOffset = (center - InputTracking.GetLocalPosition(XRNode.RightEye)).magnitude;
        eyeOffset = (leftCameraOffset + rightCameraOffset) * BothEyeOffset * 0.5f;

    }

    private void OnModelDestroied(EuclidModel model)
    {
        // この時点ですでにEuclidModelBackendは完全に破棄されているので消していくだけでよい

        Assert.IsNotNull(model);

        int index = models.IndexOf(model);
        Assert.AreNotEqual(-1, index);

        backendLeft.unregisterEuclidModel(index);
        backendRight.unregisterEuclidModel(index);
        models.RemoveAt(index);
#if UNITY_EDITOR
        TargetEuclidModel.Remove(model);
#endif
    }

    #region Unity Functions
    private void Awake()
    {
        if (playmodeChanging) { return; }

        _renderingEyeId = Shader.PropertyToID("euclid_RenderingEye");
        Assert.AreEqual(0, backendLeft.ModelCount);
        Assert.AreEqual(0, backendRight.ModelCount);

#if UNITY_EDITOR
        _instanced_models.Clear();
        _instanced_models.AddRange(TargetEuclidModel);
#endif
        foreach (var m in TargetEuclidModel)
        {
            var modelBackend = acquireBackend(m);
            backendLeft.registerEuclidModel(modelBackend.left);
            backendRight.registerEuclidModel(modelBackend.right);
        }

        Assert.AreEqual(backendLeft.ModelCount, backendRight.ModelCount);
    }

    private void OnEnable()
    {
        if (playmodeChanging) { return; }

        backendLeft.InitializeModel(transform);
        backendRight.InitializeModel(transform);
    }

    private void Start()
    {
        ResetParallaxOffset();
    }

    private void Update()
    {
        var leftEyePos   = transform.position + -transform.right * leftCameraOffset;
        var rightEyePos  = transform.position +  transform.right * rightCameraOffset;

        // カメラや3Dモデルの情報からEuclidモデルの向きに関するパラメータを更新する
        backendLeft.UpdateEuclidModelParameter(leftEyePos);
        backendRight.UpdateEuclidModelParameter(rightEyePos);
    }


    private void LateUpdate()
    {
        var leftEyePos  = transform.position + -transform.right * (leftCameraOffset  + eyeOffset);
        var rightEyePos = transform.position +  transform.right * (rightCameraOffset + eyeOffset);

        // カメラや3Dモデルの情報からEuclidモデルの向きに関するパラメータを更新する
        backendLeft.LateUpdateEuclidModelParameter(leftEyePos);
        backendRight.LateUpdateEuclidModelParameter(rightEyePos);

        //視線追跡
        EyeTrackingUpdate();
    }

    private void OnPreRender()
    {
        Shader.SetGlobalInt(_renderingEyeId, _currentEye);

        // OnPreRenderは左右それぞれ1回呼ばれるので現在のターゲットアイを入れ替える
        _currentEye = 1 - _currentEye;
    }

    private void OnPostRender()
    {
        if (!neck_Joint){ return; }

        if (auxiliaryNeck)
        {
            var tmpneck = auxiliaryExecution_rotation * Reaction_Face_Rate;
            neck_Joint.RotateAround(neck_Joint.position, horizonalStandard, tmpneck);
        }
        else
        {
            //追跡判定を行うために毎回戻す
            neck_Joint.RotateAround(neck_Joint.position, horizonalStandard, Execution_rotation);
        }
    }

    private void OnDisable()
    {
        backendLeft.Close();
        backendRight.Close();
    }

    private void OnDestroy()
    {
        Assert.AreEqual(backendLeft.ModelCount, backendRight.ModelCount);

        int index = backendLeft.ModelCount;
        while (0 < index--)
        {
            var modelBackendL = backendLeft.unregisterEuclidModel(index);
            var modelBackendR = backendRight.unregisterEuclidModel(index);
            // SceneのDestory時はEuclidModelのDestoryのほうが早い場合もあるので戻り値の検査は行わない
            releaseBackend(index, new ModelBackendPair(modelBackendL, modelBackendR));
        }
    }
    #endregion

    #region EyeTracking

    //視線追跡のフラグ
    public bool EyeTracking_W;
    public bool FaceTracking_Q;

    public bool Useparameter;

    //追跡範囲(縦)
    [Range(35, 120)]
    public int Horizontal_range = 100;
    //追跡範囲(横)
    [Range(10, 80)]
    public int Vertical_range = 65;

    //追跡範囲(下)
    [Range(10, 80)]
    public int Lower_limit = 50;

    //出された値に対して掛ける係数(何割反映させるか)
    [Range(0, 2)]
    public float FaceVerticalLimit = 0.7f;
    [Range(0, 2)]
    public float FaceHorizontalLimit = 0.7f;
    //最大値(顔のみの時のパラメータ)
    [Range(0, 2)]
    public float FaceHorixonalMax = 1;
    [Range(0, 2)]
    public float FaceVerticalMax = 1;
    //実際にかけるときに使う変数(limitとmaxを合わせてここに突っ込んでから計算)
    private float FaceHorizonalRate;
    private float FaceVerticalRate;
    //顔と同じ
    [Range(0, 3)]
    public float EyeVerticalLimit = 1.5f;
    [Range(0, 3)]
    public float EyeHorizontalLimit = 1.5f;
    //最大値(目だけの時のパラメータ)
    [Range(0, 3)]
    public float EyeHorizontalMax = 2.75f;
    [Range(0, 3)]
    public float EyeVerticalMax = 2.75f;
    private float EyeHorizonalRate;
    private float EyeVerticalRate;


    private float vertical_Adjustment = 0;
    //モデルの首がもともと傾いていた時に調節する用
    [Range(-180, 180)]
    public float vertical_neck_Adjustment = 0;

    private float horizonal_Adjustment = 0;

    //パラメータの値を受け取るやつ
    [Range(0, 1)]
    public float Reaction_Face_Rate = 1;

    [Range(0, 1)]
    public float Reaction_Eye_Rate = 1;

    //追跡範囲の形状
    public JudgeType judgeType = JudgeType.Ellipse;

    public enum JudgeType
    {
        Ellipse,
        Line,
    };

    //首回すかどうか
    public bool neck_tracking;

    [Range(0, 30)]
    public int ver_neck_rotation = 0;//どの程度まで曲げるか



    public Transform left_Shoulder;//左肩の座標
    public Transform right_Shoulder;//右肩の座標
    public Transform neck_Joint;//首の根本の座標
    public Transform neck_Tip;//首先の座標

    //追跡の際のモデルが向きたい角度
    private Vector2 trackFaceRotation = new Vector2(0, 0);
    private Vector2 trackEyeRotation = new Vector2(0, 0);
    //補助パラメータ(範囲外に行ったとき要)
    private Vector2 auxiliaryFaceRotation = new Vector2(0, 0);
    private Vector2 auxiliaryEyeRotation = new Vector2(0, 0);


    //追跡するか否かのスイッチ
    private int Face_Switch = 0;
    private int Eye_Switch = 0;

    //縦の基準ベクトル
    private Vector3 verticalStandard = new Vector3();
    //横の基準ベクトル
    private Vector3 horizonalStandard = new Vector3();



    //実際回す首の角度
    private float Execution_rotation;
    //補助パラメータ
    private float auxiliaryExecution_rotation = 0;


    //モデルから、カメラへのベクトル
    private Vector3 modelToCamera;
    //モデルとカメラの縦の角度差
    private float verticalDifference;
    //モデルからカメラへのベクトルを縦基準ベクトルに直行する平面に射影して正規化
    private Vector3 horiTmp;
    //モデルとカメラの横の角度差
    private float horizonalDifference;
    //本来の正面
    private Vector3 frontVector;
    //アニメーション上向いている向きと本来の正面との差分
    private Vector3 animationdiff;
    //視線追跡のパラメーターの値を取得
    private float trackingValue;

    //戻りの度合い
    [Range(0, 30)]
    public int auxiliaryRate = 7;

    //アシストのスイッチ
    private bool auxiliaryFace = false;
    private bool auxiliaryEye = false;
    private bool auxiliaryNeck = false;


    private void EyeTrackingUpdate()
    {

        //初期化
        trackFaceRotation.x = trackFaceRotation.y = 0;
        trackEyeRotation.x = trackEyeRotation.y = 0;
        Execution_rotation = 0;

        //パラメータによる制御。
        if (Useparameter)
        {
            Reaction_Eye_Rate = TargetEuclidModel[0].getParameterValue("PARAM_TRACKING_EYE");
            if (Reaction_Eye_Rate > 0)
            {
                EyeTracking_W = true;
            }
            else
            {
                EyeTracking_W = false;
            }
            Reaction_Face_Rate = TargetEuclidModel[0].getParameterValue("PARAM_TRACKING_FACE");
            if (Reaction_Face_Rate > 0)
            {
                FaceTracking_Q = true;
            }
            else
            {
                FaceTracking_Q = false;
            }
            //係数調整(パラメータの値によって何をどの程度動かすかを決める)
            //0除算回避
            if(Reaction_Eye_Rate == 0)
            {
                EyeHorizonalRate = EyeHorizontalLimit;
                EyeVerticalRate = EyeVerticalLimit;
                FaceHorizonalRate = FaceHorizontalLimit;
                FaceVerticalRate = FaceVerticalLimit;
            }
            else if (Reaction_Eye_Rate >= Reaction_Face_Rate)
            {
                float tmp = (Reaction_Eye_Rate - Reaction_Face_Rate) / Reaction_Eye_Rate;
                EyeHorizonalRate = EyeHorizontalLimit + (tmp * (EyeHorizontalMax - EyeHorizontalLimit));
                EyeVerticalRate = EyeVerticalLimit + (tmp * (EyeVerticalMax - EyeVerticalLimit));
                FaceHorizonalRate = FaceHorizontalLimit;
                FaceVerticalRate = FaceVerticalLimit;
            }
            else
            {
                float tmp = (Reaction_Face_Rate - Reaction_Eye_Rate) / Reaction_Face_Rate;
                FaceHorizonalRate = FaceHorizontalLimit + (tmp * (FaceHorixonalMax - FaceHorizontalLimit));
                FaceVerticalRate = FaceVerticalLimit + (tmp * (FaceVerticalMax - FaceVerticalLimit));
                EyeHorizonalRate = EyeHorizontalLimit;
                EyeVerticalRate = EyeVerticalLimit;
            }
        }
        else
        {
            //追跡のスイッチ(検証用) 
            KeyStateUpdate();
            if (Face_Switch == 1)
            {
                FaceTracking_Q = !FaceTracking_Q;
            }
            if (Eye_Switch == 1)
            {
                EyeTracking_W = !EyeTracking_W;
            }
        }

        //Debug.Log(new Vector2(FaceVerticalRate,EyeVerticalRate));

        //FBXの位置情報を利用している
        //今のところ、両肩に当たるところと、首の根本、先っちょを利用している
        //すべて設定されていると視線追跡の計算を行う
        if (left_Shoulder != null && right_Shoulder != null && neck_Joint != null && neck_Tip != null)
        {

            //カメラとモデルの角度差計算
            calcurateRad();

            //正面にいるか否か
            if (Vector3.Cross(horizonalStandard, horiTmp).y * Vector3.Cross(horizonalStandard, frontVector).y < 0)
            {
                if (horizonalDifference > 0)
                {
                    horizonalDifference = 180 - horizonalDifference;
                }
                else
                {
                    horizonalDifference = -180 - horizonalDifference;
                }
            }


            //境界判定
            //楕円判定
            if (judgeType == JudgeType.Ellipse)
            {
                if (verticalDifference * verticalDifference * Horizontal_range * Horizontal_range
                    + horizonalDifference * horizonalDifference * Vertical_range * Vertical_range
                    > Horizontal_range * Horizontal_range * Vertical_range * Vertical_range)
                {
                    horizonalDifference = verticalDifference = 0;
                }
            }
            //直線判定
            else if (judgeType == JudgeType.Line)
            {
                if (Mathf.Abs(verticalDifference) * Horizontal_range + Mathf.Abs(horizonalDifference) * Vertical_range
                    > Horizontal_range * Vertical_range)
                {
                    horizonalDifference = verticalDifference = 0;
                }
            }

            //下限判定
            if (verticalDifference < -Lower_limit)
            {
                horizonalDifference = verticalDifference = 0;
            }


            //追跡範囲外なら
            bool inRange = true;
            if ((horizonalDifference == 0 && verticalDifference == 0))
            {
                inRange = false;
                //アシストスイッチ
                if (Reaction_Face_Rate > 0)
                {
                    auxiliaryFace = true;
                    auxiliaryNeck = true;

                }
                if (Reaction_Eye_Rate > 0)
                {
                    auxiliaryEye = true;
                }
            }

            //パラメータが0ならアシスト解除
            if (Reaction_Face_Rate == 0)
            {
                auxiliaryFace = false;
                auxiliaryNeck = false;
            }
            if (Reaction_Eye_Rate == 0)
            {
                auxiliaryEye = false;
            }



            //顔の追跡をしていて、かつ首の追跡をするなら
            if (FaceTracking_Q && neck_tracking)
            {
                //首を回すように計算
                regulationParameter(ref Execution_rotation, (verticalDifference / Vertical_range * ver_neck_rotation), Reaction_Face_Rate);
            }
            else
            {
                //でなかったら戻すように計算
                regulationParameter(ref Execution_rotation, 0, Reaction_Face_Rate);
            }

            //アシスト用計算
            if (FaceTracking_Q && neck_tracking)
            {
                regulationParameter(ref auxiliaryExecution_rotation, (verticalDifference / Vertical_range * ver_neck_rotation), auxiliaryRate);
            }
            else
            {
                regulationParameter(ref auxiliaryExecution_rotation, 0, auxiliaryRate);
            }


            //首を回す
            if (auxiliaryNeck)
            {
                var tmpneck = auxiliaryExecution_rotation * Reaction_Face_Rate;
                neck_Joint.RotateAround(neck_Joint.position, horizonalStandard, -tmpneck);
                if (tmpneck - Execution_rotation < 0.1f && tmpneck - Execution_rotation > -0.1f && inRange)
                {
                    auxiliaryNeck = false;
                }
            }
            else
            {
                neck_Joint.RotateAround(neck_Joint.position, horizonalStandard, -Execution_rotation);
            }


            //追跡範囲内なら
            if (!(horizonalDifference == 0 && verticalDifference == 0))
            {
                //首が回っている状態での向き計算を再度する
                calcurateRad();
            }

            //正面への補正
            verticalDifference -= animationdiff.x + vertical_Adjustment;
            horizonalDifference += animationdiff.y + horizonal_Adjustment;


            //モデルが向く角度を取る
            if (FaceTracking_Q)
            {
                regulationParameter(ref trackFaceRotation.x, verticalDifference, Reaction_Face_Rate);
                regulationParameter(ref trackFaceRotation.y, horizonalDifference, Reaction_Face_Rate);
            }
            else
            {
                regulationParameter(ref trackFaceRotation.x, 0, Reaction_Face_Rate);
                regulationParameter(ref trackFaceRotation.y, 0, Reaction_Face_Rate);
            }

            if (EyeTracking_W)
            {
                regulationParameter(ref trackEyeRotation.x, verticalDifference, Reaction_Eye_Rate);
                regulationParameter(ref trackEyeRotation.y, horizonalDifference, Reaction_Eye_Rate);
            }
            else
            {
                regulationParameter(ref trackEyeRotation.x, 0, Reaction_Eye_Rate);
                regulationParameter(ref trackEyeRotation.y, 0, Reaction_Eye_Rate);
            }

            //アシスト用計算
            if (FaceTracking_Q)
            {
                regulationParameter(ref auxiliaryFaceRotation.x, verticalDifference, auxiliaryRate);
                regulationParameter(ref auxiliaryFaceRotation.y, horizonalDifference, auxiliaryRate);
            }
            else
            {
                regulationParameter(ref auxiliaryFaceRotation.x, 0, auxiliaryRate);
                regulationParameter(ref auxiliaryFaceRotation.y, 0, auxiliaryRate);
            }

            if (EyeTracking_W)
            {
                regulationParameter(ref auxiliaryEyeRotation.x, verticalDifference, auxiliaryRate);
                regulationParameter(ref auxiliaryEyeRotation.y, horizonalDifference, auxiliaryRate);
            }
            else
            {
                regulationParameter(ref auxiliaryEyeRotation.x, 0, auxiliaryRate);
                regulationParameter(ref auxiliaryEyeRotation.y, 0, auxiliaryRate);
            }



            float drawRotation_y, drawRotation_x;
            float eyeballRotation_y, eyeballRotation_x;
            if (auxiliaryFace)
            {
                var tmpFace = auxiliaryFaceRotation * Reaction_Face_Rate;
                //モデルが向きたい角度をもとに、視線と顔の向きを計算
                drawRotation_y = tmpFace.x * FaceVerticalRate;
                drawRotation_x = tmpFace.y * FaceHorizonalRate;
                if (tmpFace.x - trackFaceRotation.x < 1f && tmpFace.x - trackFaceRotation.x > -1f
                    && tmpFace.y - trackFaceRotation.y < 1f && tmpFace.y - trackFaceRotation.y > -1f && inRange)
                {
                    auxiliaryFace = false;
                }

            }
            else
            {
                //モデルが向きたい角度をもとに、視線と顔の向きを計算
                drawRotation_y = trackFaceRotation.x * FaceVerticalRate;
                drawRotation_x = trackFaceRotation.y * FaceHorizonalRate;
            }

            if (auxiliaryEye)
            {
                var tmpEye = auxiliaryEyeRotation * Reaction_Eye_Rate;
                eyeballRotation_y = tmpEye.x / (Vertical_range) * EyeVerticalRate;
                eyeballRotation_x = tmpEye.y / (Horizontal_range) * EyeHorizonalRate;
                if (tmpEye.x - trackFaceRotation.x < 1f && tmpEye.x - trackFaceRotation.x > -1f
                     && tmpEye.y - trackFaceRotation.y < 1f && tmpEye.y - trackFaceRotation.y > -1f && inRange)
                {
                    auxiliaryEye = false;
                }

            }
            else
            {
                //モデルが向きたい角度をもとに、視線と顔の向きを計算
                eyeballRotation_y = trackEyeRotation.x / (Vertical_range) * EyeVerticalRate;
                eyeballRotation_x = trackEyeRotation.y / (Horizontal_range) * EyeHorizonalRate;
            }

            if (EyeTracking_W)
            {
                //視線の角度をセット
                TargetEuclidModel[0].setParameterValue("PARAM_EYE_BALL_X", -eyeballRotation_x);
                TargetEuclidModel[0].setParameterValue("PARAM_EYE_BALL_Y", eyeballRotation_y);
            }

            var leftEyePos = transform.position + -transform.right * (leftCameraOffset + eyeOffset);
            var rightEyePos = transform.position + transform.right * (rightCameraOffset + eyeOffset);


            // カメラや3Dモデルの情報からEuclidモデルの向きに関するパラメータを更新する
            backendLeft.LateUpdateEuclidModelParameter(leftEyePos, -drawRotation_x, drawRotation_y);
            backendRight.LateUpdateEuclidModelParameter(rightEyePos, -drawRotation_x, drawRotation_y);

            //Debug.Log(new Vector2(-drawRotation_x, drawRotation_y));
        }
        else
        {
            var leftEyePos = transform.position + -transform.right * (leftCameraOffset + eyeOffset);
            var rightEyePos = transform.position + transform.right * (rightCameraOffset + eyeOffset);


            // カメラや3Dモデルの情報からEuclidモデルの向きに関するパラメータを更新する
            backendLeft.LateUpdateEuclidModelParameter(leftEyePos, 0, 0);
            backendRight.LateUpdateEuclidModelParameter(rightEyePos, 0, 0);

        }

    }


    //カメラとモデルの角度差計算
    private void calcurateRad()
    {

        //モデルから、カメラへのベクトル
        modelToCamera = (this.transform.position - this.TargetEuclidModel[0].transform.position).normalized;

        //首の座標から、縦向きに関する基準ベクトルを作る
        verticalStandard = (neck_Tip.position - neck_Joint.position).normalized;


        //肩の座標から、横向きに関しての基準ベクトルを作る
        horizonalStandard = (right_Shoulder.position - left_Shoulder.position).normalized;

        //直交化
        horizonalStandard = (horizonalStandard - Vector3.Dot(horizonalStandard, verticalStandard) * verticalStandard).normalized;


        //(もしあれば)縦族補正
        verticalStandard = Quaternion.AngleAxis(vertical_neck_Adjustment, horizonalStandard) * verticalStandard;

        //モデルとカメラの縦の角度差を取る(裏表区別なし)
        verticalDifference = Mathf.Asin(Vector3.Dot(verticalStandard, modelToCamera)) * Mathf.Rad2Deg;

        //モデルからカメラへのベクトルを縦基準ベクトルに直行する平面に射影して正規化
        horiTmp = (modelToCamera - Vector3.Dot(modelToCamera, verticalStandard) * verticalStandard).normalized;
        //モデルとカメラの横の角度差を取る
        horizonalDifference = Mathf.Asin(Vector3.Dot(horizonalStandard, horiTmp)) * Mathf.Rad2Deg;

        //アニメーション上向いている向きと本来の正面との差分
        frontVector = Vector3.Cross(horizonalStandard, verticalStandard);
        animationdiff = Quaternion.LookRotation(frontVector).eulerAngles - this.TargetEuclidModel[0].configure.RootJoint.eulerAngles;
        if (animationdiff.x > 180) animationdiff.x -= 360;
        if (animationdiff.y > 180) animationdiff.y -= 360;
        if (animationdiff.x < -180) animationdiff.x += 360;
        if (animationdiff.y < -180) animationdiff.y += 360;
    }


    //カメラの角度から、向きたい角度を計算
    private void regulationParameter(ref float from, float to, float rate)
    {
        from = (to - from) * rate;
    }

    //外れた際の補助(？)パラメータ計算
    private void regulationParameter(ref float from, float to, int speed)
    {

        if (Mathf.Abs(from - to) > 0.5f)
        {
            from = (from * speed + to) / (speed + 1);
        }
        else
        {
            //ある程度近くなったら固定
            from = to;
        }
    }



    //手動で切り替えるためのスイッチ
    private void KeyStateUpdate()
    {
        if (Input.GetKey(KeyCode.Q))
        {
            Face_Switch++;
        }
        else
        {
            Face_Switch = 0;
        }

        if (Input.GetKey(KeyCode.W))
        {
            Eye_Switch++;
        }
        else
        {
            Eye_Switch = 0;
        }

    }

    #endregion


}
