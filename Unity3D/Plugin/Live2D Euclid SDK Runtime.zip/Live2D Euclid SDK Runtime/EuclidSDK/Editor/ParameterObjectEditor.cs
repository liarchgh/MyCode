﻿/*
*Copyright(c) Live2D Inc. All rights reserved.
*このソースコードの使用には、"http://www.live2d.com/eula/live2d-open-software-license-agreement_jp.html"ファイルにあるLive2D Open Software ライセンスが適用されます。
*Use of this source code is governed by a Live2D Open Software license that can be found in the "http://www.live2d.com/eula/live2d-open-software-license-agreement_en.html" file.
*/

using UnityEngine;
using UnityEngine.Assertions;
using UnityEditor;
using live2d.Euclid;

namespace live2d.Euclid_Editor
{
    [CustomEditor(typeof(ParameterObject))]
    public class ParameterObjectEditor : Editor
    {
        private ParameterRoot      root;
        private ParameterInfo[]    infos;
        private SerializedProperty valueProp;

        private ParameterRoot GetRoot()
        {
            var obj = target as ParameterObject;
            Assert.IsNotNull(obj);

            var root = obj.transform.parent;
            if (root == null) { return null; }

            return root.GetComponent<ParameterRoot>();
        }

        private ParameterInfo[] GetParametersInfo()
        {
            var parent = root.transform.parent;
            if (parent == null) { return null; }

            var model = parent.GetComponent<EuclidModel>();
            if (model == null) { return null; }

            var infos = EuclidModelBackend.GetParametersInfo(model.configure);
            Assert.IsNotNull(infos);
            return infos;
        }

        private void OnEnable()
        {
            valueProp = serializedObject.FindProperty("value");

            root = GetRoot();
            if (root == null) { return; }
            infos = GetParametersInfo();
        }

        public override void OnInspectorGUI()
        {
            var root = GetRoot();
            if (root == null)
            {
                EditorGUILayout.HelpBox(
                    "This GameObject should be direct child of ParameterRoot component.",
                    MessageType.Error, true);
                return;
            }

            if (this.root != root)
            {
                this.root = root;
                infos = GetParametersInfo();
            }
            if (infos == null)
            {
                return;
            }

            serializedObject.Update();

            var obj = target as ParameterObject;
            Assert.IsNotNull(obj);

            foreach (var info in infos)
            {
                if (info.Name == obj.name)
                {
                    EditorGUILayout.Slider(valueProp, info.MinimumValue, info.MaximumValue, new GUIContent("value"));
                    serializedObject.ApplyModifiedProperties();
                    break;
                }
            }
        }

        private void OnDisable()
        {
            infos = null;
        }
    }
}

