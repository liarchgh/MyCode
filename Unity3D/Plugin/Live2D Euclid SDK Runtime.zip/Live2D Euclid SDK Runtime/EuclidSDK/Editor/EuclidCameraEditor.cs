﻿/*
*Copyright(c) Live2D Inc. All rights reserved.
*このソースコードの使用には、"http://www.live2d.com/eula/live2d-open-software-license-agreement_jp.html"ファイルにあるLive2D Open Software ライセンスが適用されます。
*Use of this source code is governed by a Live2D Open Software license that can be found in the "http://www.live2d.com/eula/live2d-open-software-license-agreement_en.html" file.
*/

using System.Linq;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEditor;

[CustomEditor(typeof(EuclidCamera))]
public class EuclidCameraEditor : Editor
{
    private EuclidCamera Camera { get { return target as EuclidCamera; } }

    private SerializedProperty models;

    private void Awake()
    {
        models = serializedObject.FindProperty("TargetEuclidModel");

        Debug.Assert(models.isArray);
    }

    public override void OnInspectorGUI()
    {
        EditorGUILayout.HelpBox(
            "Please note that, duplicating will cause unexpected status.",
            MessageType.Warning, true);

        serializedObject.Update();

        var pre = Enumerable.Range(0, models.arraySize)
            .Select(i => models.GetArrayElementAtIndex(i).objectReferenceValue as EuclidModel)
            .Where(e => e != null)
            .ToList()
            ;

        DrawDefaultInspector();

        serializedObject.ApplyModifiedProperties();

        var post = Enumerable.Range(0, models.arraySize)
            .Select(i => models.GetArrayElementAtIndex(i).objectReferenceValue as EuclidModel)
            .Where(e => e != null)
            .ToList()
            ;

        foreach (var model in pre.Except(post))
        {
            Camera.RemoveEuclidModel(model);
        }
        foreach (var model in post.Except(pre))
        {
            Camera.AddEuclidModel(model);
        }
    }
}
