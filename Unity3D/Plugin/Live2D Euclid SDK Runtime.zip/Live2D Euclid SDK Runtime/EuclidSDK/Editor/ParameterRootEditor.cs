﻿/*
*Copyright(c) Live2D Inc. All rights reserved.
*このソースコードの使用には、"http://www.live2d.com/eula/live2d-open-software-license-agreement_jp.html"ファイルにあるLive2D Open Software ライセンスが適用されます。
*Use of this source code is governed by a Live2D Open Software license that can be found in the "http://www.live2d.com/eula/live2d-open-software-license-agreement_en.html" file.
*/

using UnityEngine;
using UnityEngine.Assertions;
using UnityEditor;
using live2d.Euclid;

namespace live2d.Euclid_Editor
{
    [CustomEditor(typeof(ParameterRoot))]
    public class ParameterRootEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            var root = target as ParameterRoot;
            Assert.IsNotNull(root);

            if (root.gameObject.name != "Parameters")
            {
                EditorGUILayout.HelpBox(
                    "The name of this GameObject should be \"Parameters\"," +
                    " or doesn't work with animation properly.",
                    MessageType.Warning, true);
            }

            var parent = root.transform.parent;
            if (parent == null || parent.GetComponent<EuclidModel>() == null)
            {
                EditorGUILayout.HelpBox(
                    "This GameObject should be direct child of EuclidModel component.",
                    MessageType.Error, true);
                return;
            }
        }
    }
}
