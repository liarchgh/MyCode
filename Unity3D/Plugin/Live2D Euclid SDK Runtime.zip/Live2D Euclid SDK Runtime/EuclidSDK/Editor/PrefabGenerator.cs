﻿/*
*Copyright(c) Live2D Inc. All rights reserved.
*このソースコードの使用には、"http://www.live2d.com/eula/live2d-open-software-license-agreement_jp.html"ファイルにあるLive2D Open Software ライセンスが適用されます。
*Use of this source code is governed by a Live2D Open Software license that can be found in the "http://www.live2d.com/eula/live2d-open-software-license-agreement_en.html" file.
*/

using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEditor;
using live2d.Euclid;

namespace live2d.Euclid_Editor
{
    public static class PrefabGenerator
    {
        [MenuItem("Assets/Euclid/Generate Prefab from moe(bytes)", true)]
        public static bool canConvertToPrefab()
        {
            var guids = Selection.assetGUIDs;
            var assetPath = guids.Select(AssetDatabase.GUIDToAssetPath);
            var assetName = assetPath.Where(p => p.EndsWith(".bytes", StringComparison.OrdinalIgnoreCase));
            var str = assetName.Select(AssetDatabase.LoadAssetAtPath<TextAsset>);
            var valid = str.Any(a => EuclidModelAsset.IsValidTextAsset(a));
            return valid;
        }

        // 選択されているものの内、有効なmoeを指しているものは全て変換する
        [MenuItem("Assets/Euclid/Generate Prefab from moe(bytes)")]
        public static void convertToPrefab()
        {
            AssetDatabase.StartAssetEditing();

            Selection.objects = Selection.assetGUIDs
                .Select(AssetDatabase.GUIDToAssetPath)
                .Where(p => p.EndsWith(".bytes", StringComparison.OrdinalIgnoreCase))
                .Select(AssetDatabase.LoadAssetAtPath<TextAsset>)
                .Where(a => EuclidModelAsset.IsValidTextAsset(a))
                .Select(createModelPrefab)
                .ToArray()
                ;

            AssetDatabase.SaveAssets();

            AssetDatabase.StopAssetEditing();
        }

        private static UnityEngine.Object createModelPrefab(TextAsset asset)
        {
            var path = AssetDatabase.GetAssetPath(asset);
            Debug.Assert(path.EndsWith(".bytes", StringComparison.OrdinalIgnoreCase));

            path = path.Substring(0, path.Length - ".bytes".Length) + ".prefab";

            var textures = GetTextureList(asset);

            return createModelPrefab(asset, textures, path);
        }

        // TextAssetやTexture2DはPrefabに含めない
        // Materialはどっちにしろ含めない
        private static UnityEngine.Object createModelPrefab(TextAsset asset, Texture2D[] textures, string path)
        {
            Debug.Assert(EuclidModelAsset.IsValidTextAsset(asset), asset);
            Debug.Assert(path.EndsWith(".prefab", StringComparison.OrdinalIgnoreCase));

            // 以下の手順だとComponentからAssetへの参照が消えてしまってうまくいかない
            //   1. Prefabを作るGameObjectの構築を完了する
            //   2. ComponentにAssetを設定していく
            //   3. GameObjectからPrefabを作る
            //   4. PrefabにAssetを追加していく
            //
            // これはPrefabを作った時点でPrefabに含まれていないAssetへの参照が無効になってしまうから
            // なので先に空のPrefabを作ってしまい、Assetをひと通り追加し終わった後にPrefabのメインアセットをすげ替える
            var prefab = PrefabUtility.CreateEmptyPrefab(path);
            Assert.IsNotNull(prefab);

            var ma = EuclidModelAsset.CreateInstance(asset);
            ma.name = asset.name;
            AssetDatabase.AddObjectToAsset(ma, prefab);

            var model = new GameObject(asset.name, typeof(Animator), typeof(EuclidModel));
            var configure = model.GetComponent<EuclidModel>().configure;

            configure.ModelAsset  = ma;
            configure.TextureList = textures;
            EuclidConfigEditor.FetchConfiguration(configure);
            LoadDefaultMaterials(configure);

#pragma warning disable 0219
            var param = createParameters(model, ma);
#pragma warning restore 0219
            var phys  = createPhysPoints(model, ma);

            if (phys != null)
            {
                // 物理点が存在するならアニメーションのためにアバターを作って設定しておく

                var avatar = AvatarBuilder.BuildGenericAvatar(model, "");
                avatar.name = asset.name + "Avatar";

                AssetDatabase.AddObjectToAsset(avatar, prefab);

                model.GetComponent<Animator>().avatar = avatar;
            }

            prefab = PrefabUtility.ReplacePrefab(model, prefab);
            Assert.IsNotNull(prefab);

            GameObject.DestroyImmediate(model);

            return prefab;
        }

        private static GameObject createParameters(GameObject root, EuclidModelAsset asset)
        {
            var infos = asset.GetParametersInfo();
            if (infos.Length == 0) { return null; }

            var param = new GameObject("Parameters", typeof(ParameterRoot));
            param.transform.SetParent(root.transform, false);

            foreach (var info in infos)
            {
                var obj = new GameObject(info.Name, typeof(ParameterObject));
                obj.transform.SetParent(param.transform, false);

                var po   = obj.GetComponent<ParameterObject>();
                po.value = info.DefaultValue;

                // gameObject.nameを参照するとnativeから取得する関係でGCallocが走ることになる
                // コンポーネント内でIDを保持しておいて使いまわすようにする
                // 実行中にnameとの乖離があった場合の動作は未定義とする
                po.NameCache = info.Name;
            }

            return param;
        }

        private static GameObject createPhysPoints(GameObject root, EuclidModelAsset asset)
        {
            // 物理点があるかどうかを事前に調べられないので投機的に構築して、子がなければ棄てる

            var phys = new GameObject("Physics", typeof(PhysicsPointRoot));
            phys.transform.SetParent(root.transform, false);

            PhysicsPointRoot.GenerateBoneStructure(phys, asset);

            if (phys.transform.childCount == 0)
            {
                GameObject.DestroyImmediate(phys);
                return null;
            }

            return phys;
        }

        private static Texture2D[] GetTextureList(TextAsset asset)
        {
            Assert.IsNotNull(asset);

            var path = AssetDatabase.GetAssetPath(asset);
            path = path.Substring(0, path.Length - System.IO.Path.GetExtension(path).Length);

            return AssetDatabase.FindAssets("t:texture2D", new string[]{path})
                .Select(AssetDatabase.GUIDToAssetPath)
                .Select(AssetDatabase.LoadAssetAtPath<Texture2D>)
                .ToArray()
                ;
        }

        private static Material GetMaterial(string name)
        {
            return AssetDatabase.FindAssets(name + " t:Material")
                .Select(AssetDatabase.GUIDToAssetPath)
                // FindAssetsは含むかどうかで検索するので本当に指定した名前かどうか確認する必要がある
                .Where(p => p.EndsWith(name + ".mat", StringComparison.OrdinalIgnoreCase))
                .Select(AssetDatabase.LoadAssetAtPath<Material>)
                .FirstOrDefault()
                ;
        }

        private static void LoadDefaultMaterials(EuclidModelConfig configure)
        {
            configure.MaskMaterial                  = GetMaterial("EuclidMask");
            configure.ModelNormalMaterial           = GetMaterial("EuclidModel_normal");
            configure.ModelAdditiveMaterial         = GetMaterial("EuclidModel_additive");
            configure.ModelMultiplyMaterial         = GetMaterial("EuclidModel_multiply");
            configure.ModelMaskedNormalMaterial     = GetMaterial("EuclidMaskedModel_normal");
            configure.ModelMaskedAdditiveMaterial   = GetMaterial("EuclidMaskedModel_additive");
            configure.ModelMaskedMultiplyMaterial   = GetMaterial("EuclidMaskedModel_multiply");
            configure.SSBaseMaterial                = GetMaterial("EuclidSSBase");
            configure.SSMaskMaterial                = GetMaterial("EuclidSSMask");
            configure.ModelSSMaskedNormalMaterial   = GetMaterial("EuclidSSModel_normal");
            configure.ModelSSMaskedAdditiveMaterial = GetMaterial("EuclidSSModel_additive");
            configure.ModelSSMaskedMultiplyMaterial = GetMaterial("EuclidSSModel_multiply");
        }
    }
}
