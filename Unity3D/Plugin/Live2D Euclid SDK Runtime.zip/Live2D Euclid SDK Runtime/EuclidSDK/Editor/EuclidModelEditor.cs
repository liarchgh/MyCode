﻿/*
*Copyright(c) Live2D Inc. All rights reserved.
*このソースコードの使用には、"http://www.live2d.com/eula/live2d-open-software-license-agreement_jp.html"ファイルにあるLive2D Open Software ライセンスが適用されます。
*Use of this source code is governed by a Live2D Open Software license that can be found in the "http://www.live2d.com/eula/live2d-open-software-license-agreement_en.html" file.
*/

using System;
using UnityEngine;
using UnityEditor;
using live2d.Euclid;

[CustomEditor(typeof(EuclidModel))]
public class EuclidModelEditor : live2d.Euclid_Editor.EuclidConfigEditor
{
    protected override EuclidModelConfig configure // Mandatory
    {
        get { return (target as EuclidModel).configure; }
    }
    protected override string configurePath // Mandatory
    {
        get { return "configure"; }
    }

    public override void OnInspectorGUI()
    {
        var model = target as EuclidModel;

        DrawAssetInspector(model);

        if (model.configure.ModelAsset != null || model.configure.EuclidFile != null)
        {
            DrawConfigInspector();
        }

        serializedObject.ApplyModifiedProperties();
    }

    private void DrawAssetInspector(EuclidModel model)
    {
        TextAsset fileAsset = null;
        live2d.Euclid.EuclidModelAsset modelAsset = null;

        if (model.configure.EuclidFile != null)
        {
            fileAsset = AssetField("Model (deprecated)", model.configure.EuclidFile, false);
            EditorGUILayout.HelpBox(
                "It is recommended that use EuclidModelAsset instead of .bytes;" +
                "it will improve memory footprint, IO, scene transition time, and any other loading performance.",
                MessageType.Info, true);
        }
        else
        {
            modelAsset = AssetField("Euclid Model", model.configure.ModelAsset, false);
            if (model.configure.ModelAsset == null)
            {
                // どちらのアセットもnullだった場合は互換モードに入れるようにする
                fileAsset = AssetField("Model (deprecated)", model.configure.EuclidFile, false);
            }
        }

        // どちらもあるのはおかしい
        Debug.Assert(modelAsset == null || fileAsset == null);

        // インスペクタ上でアセットが変化していたらテクスチャの再読込を行う
        if (modelAsset != model.configure.ModelAsset || fileAsset != model.configure.EuclidFile)
        {
            Undo.RecordObject(target, "Change Euclid Model");

            model.configure.ModelAsset = modelAsset;
            model.configure.EuclidFile = fileAsset;
            ResetMaterials(model, modelAsset != null ? (UnityEngine.Object)modelAsset : fileAsset);
        }
    }

    private void ResetMaterials(EuclidModel model, UnityEngine.Object asset)
    {
        model.configure.TextureList                   = GetTextureList(asset);
        model.configure.MaskMaterial                  = GetMaterial("EuclidMask");
        model.configure.ModelNormalMaterial           = GetMaterial("EuclidModel_normal");
        model.configure.ModelAdditiveMaterial         = GetMaterial("EuclidModel_additive");
        model.configure.ModelMultiplyMaterial         = GetMaterial("EuclidModel_multiply");
        model.configure.ModelMaskedNormalMaterial     = GetMaterial("EuclidMaskedModel_normal");
        model.configure.ModelMaskedAdditiveMaterial   = GetMaterial("EuclidMaskedModel_additive");
        model.configure.ModelMaskedMultiplyMaterial   = GetMaterial("EuclidMaskedModel_multiply");
        model.configure.SSBaseMaterial                = GetMaterial("EuclidSSBase");
        model.configure.SSMaskMaterial                = GetMaterial("EuclidSSMask");
        model.configure.ModelSSMaskedNormalMaterial   = GetMaterial("EuclidSSModel_normal");
        model.configure.ModelSSMaskedAdditiveMaterial = GetMaterial("EuclidSSModel_additive");
        model.configure.ModelSSMaskedMultiplyMaterial = GetMaterial("EuclidSSModel_multiply");
    }

    private static Texture2D GUIDToTexture2D(string guid)
    {
        var path = AssetDatabase.GUIDToAssetPath(guid);
        return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
    }

    private Texture2D[] GetTextureList(UnityEngine.Object asset)
    {
        // アセットは削除されてもよい
        if (asset == null) { return null; }

        var apath = AssetDatabase.GetAssetPath(asset);

        var path = System.IO.Path.GetDirectoryName(apath);
        var dirname = System.IO.Path.GetFileNameWithoutExtension(apath);

        path = System.IO.Path.Combine(path, dirname);

        var textures = AssetDatabase.FindAssets("t:texture2D", new string[]{path});
        return Array.ConvertAll(textures, GUIDToTexture2D);
    }

    private Material GetMaterial(string name)
    {
        var mat = AssetDatabase.FindAssets(name + " t:Material");
        if (mat == null || mat.Length == 0) { return null; }

        if (1 < mat.Length)
        {
            EditorGUILayout.HelpBox("Two or more materials are found.", MessageType.Warning, true);
        }

        var path = AssetDatabase.GUIDToAssetPath(mat[0]);
        return AssetDatabase.LoadAssetAtPath<Material>(path);
    }
}
