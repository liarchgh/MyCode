﻿/*
*Copyright(c) Live2D Inc. All rights reserved.
*このソースコードの使用には、"http://www.live2d.com/eula/live2d-open-software-license-agreement_jp.html"ファイルにあるLive2D Open Software ライセンスが適用されます。
*Use of this source code is governed by a Live2D Open Software license that can be found in the "http://www.live2d.com/eula/live2d-open-software-license-agreement_en.html" file.
*/

using System;
using UnityEngine;
using UnityEditor;

namespace live2d.Euclid.EditorExtensions
{
    using UnityEngine.Rendering;

    [InitializeOnLoad]
    public sealed class MaterialTweaker
    {
        static MaterialTweaker()
        {
            Tweak(false, (MaterialAsset a) => a.SetDirty());
        }

        [MenuItem("Assets/Euclid/Generate Default Materials")]
        private static void GenerateDefaultMaterials()
        {
            Tweak(true, (MaterialAsset a) => a.CreateAsset());
        }

        private enum BlendingMethod
        {
            Normal,   // Cs*As + Cd*(1-As)
            Additive, // Cs*As + Cd
            Multiply, // Cs*Cd + Cd*(1-As)
        }

        private struct MaterialAsset
        {
            public string   path;
            public Material material;

            public static explicit operator bool(MaterialAsset asset)
            {
                return asset.material != null;
            }

            public void SetDirty()
            {
                EditorUtility.SetDirty(material);
            }

            public void CreateAsset()
            {
                if (AssetDatabase.Contains(material))
                {
                    SetDirty();
                }
                else
                {
                    AssetDatabase.CreateAsset(material, path);
                }
            }

            public void SetBlendMode(BlendMode sC, BlendMode dC, BlendMode sA, BlendMode dA)
            {
                material.SetInt("_BlendSrcColor", (int)sC);
                material.SetInt("_BlendDstColor", (int)dC);
                material.SetInt("_BlendSrcAlpha", (int)sA);
                material.SetInt("_BlendDstAlpha", (int)dA);
            }

            public void SetBlendingMethod(BlendingMethod method)
            {
                switch (method)
                {
                case BlendingMethod.Normal:
                    SetBlendMode(BlendMode.One,      BlendMode.OneMinusSrcAlpha,
                                 BlendMode.SrcAlpha, BlendMode.OneMinusSrcAlpha);
                    break;

                case BlendingMethod.Additive:
                    SetBlendMode(BlendMode.One,  BlendMode.One,
                                 BlendMode.Zero, BlendMode.One);
                    break;

                case BlendingMethod.Multiply:
                    SetBlendMode(BlendMode.DstColor, BlendMode.OneMinusSrcAlpha,
                                 BlendMode.SrcAlpha, BlendMode.OneMinusSrcAlpha);
                    break;
                }
            }
        }

        private delegate void Finalizer(MaterialAsset a);
        private static void Tweak(bool create, Finalizer fin)
        {
            var mask = RealizeMaterialShader("Euclid/EuclidMaskShader", "EuclidMask.mat", create);
            if ((bool)mask)
            {
                mask.material.EnableKeyword("EUCLID_ENABLE_MASK");
                // CommandBufferでテクスチャを参照しない問題があるので、2017.3では一時的にGPU Instaincingを無効にする
#if UNITY_2017_3_OR_NEWER
                mask.material.enableInstancing = false;
#else
                mask.material.enableInstancing = true;
#endif
                fin(mask);
            }

            RealizeBlendedMaterials("Euclid/EuclidModelShader", "EuclidModel", create,
                (MaterialAsset a) => { a.material.DisableKeyword("EUCLID_ENABLE_MASK"); fin(a); });

            RealizeBlendedMaterials("Euclid/EuclidModelShader", "EuclidMaskedModel", create,
                (MaterialAsset a) => { a.material.EnableKeyword("EUCLID_ENABLE_MASK"); fin(a); });


            var ssbase = RealizeMaterialShader("Euclid/EuclidSSBaseShader", "EuclidSSBase.mat", create);
            if ((bool)ssbase)
            {
                fin(ssbase);
            }

            var ssmask = RealizeMaterialShader("Euclid/EuclidSSMaskShader", "EuclidSSMask.mat", create);
            if ((bool)ssmask)
            {
                fin(ssmask);
            }

            RealizeBlendedMaterials("Euclid/EuclidSSModelShader", "EuclidSSModel", create, fin);
        }

        private static MaterialAsset RealizeMaterialShader(string name, string matName, bool create)
        {
            var shader = Shader.Find(name);
            Debug.Assert(shader != null);

            var dir = GetMaterialDirFromShader(shader);

            var path = System.IO.Path.Combine(dir, matName);
            Material m = LoadMaterialAtPath(path);

            if (m == null)
            {
                if (!create) { return new MaterialAsset(); }

                m = new Material(shader);
            }
            else
            {
                m.shader = shader;
            }

            return new MaterialAsset
            {
                path     = path,
                material = m
            };
        }

        private static void RealizeBlendedMaterials(string shader, string matNamePrefix, bool create, Finalizer fin)
        {
            var norm = RealizeMaterialShader(shader, matNamePrefix + "_normal.mat", create);
            if ((bool)norm)
            {
                norm.SetBlendingMethod(BlendingMethod.Normal);
                fin(norm);
            }

            var addi = RealizeMaterialShader(shader, matNamePrefix + "_additive.mat", create);
            if ((bool)addi)
            {
                addi.SetBlendingMethod(BlendingMethod.Additive);
                fin(addi);
            }

            var mult = RealizeMaterialShader(shader, matNamePrefix + "_multiply.mat", create);
            if ((bool)mult)
            {
                mult.SetBlendingMethod(BlendingMethod.Multiply);
                fin(mult);
            }
        }

        private static string GetMaterialDirFromShader(Shader shader)
        {
            // path/to/sdk/Resources/Shaders/blahblahblah.shader
            var path = AssetDatabase.GetAssetPath(shader);

            // path/to/sdk/Resources/Shaders/
            path = System.IO.Path.GetDirectoryName(path);

            // path/to/sdk/Resources/
            path = System.IO.Path.GetDirectoryName(path);

            // path/to/sdk/Resources/Materials
            return System.IO.Path.Combine(path, "Materials");
        }

        private static Material LoadMaterialAtPath(string path)
        {
            return AssetDatabase.LoadAssetAtPath<Material>(path);
        }
    }
}
