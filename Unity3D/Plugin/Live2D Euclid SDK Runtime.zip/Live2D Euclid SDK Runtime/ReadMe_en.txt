============================================================
    Live2D Euclid SDK Runtime for Unity Version 1.4.0.0

    (c) Live2D Inc.
============================================================

This is a Software Development Kit (SDK) for developing applications powerd by Live2D Euclid on Unity
The SDK contains proprietary libraries and sample projects.
Read this document before using the SDK.

------------------------------
    License
------------------------------

    Read Live2D License Agreement

    Live2D SDK License Agreement, http://www.live2d.com/eula/live2d-proprietary-software-license-agreement_en.html
    By downloading, installing or using this file and other parts of Live2D SDK,
    you are agreeing that you understand Live2D SDK License Agreement and accept
    all of its terms. If you do not understand or agree to the terms of this
    Agreement, you may not use any part of Live2D SDK. You may not modify or
    delete this statement.

------------------------------
    Online Manual
------------------------------

Please check supported platforms and system requirements in these websites.

    Live2D Euclid SDK Manual
    http://docs.live2d.com/euclid-sdk-manual/top/

    Live2D Euclid SDK Tutorial
    http://docs.live2d.com/euclid-sdk-tutorials/top/

------------------------------
    Support
------------------------------

    SDK support and customization services are available.
�@Please inquire about details and price through our website.
    http://live2d.com/en/

------------------------------
    User Community
------------------------------

    Share knowledge with other creators and developers at Live2D community.

    http://community.live2d.com/

------------------------------
    Release Note
------------------------------

    2018/06/27 Version 1.4.0.0
    2018/03/27 Version 1.3.0.2
    2018/03/07 Version 1.3.0.1
    2018/02/07 Version 1.3.0.0
    2017/12/20 Version 1.2.1.0
    2017/11/28 Version 1.2.0.0
    2017/07/26 Version 1.1.0.0
    2017/06/28 Version 1.0.2.0
    2017/05/24 Version 1.0.1.0
    2017/04/26 Version 1.0.0.0

